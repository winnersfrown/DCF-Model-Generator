# dcf-model-generator

A small, well-tested Python toolkit for building discounted cash flow (DCF)
valuations — as a Python library, a CLI, a formula-driven Excel workbook, or
a live interactive browser demo.

**[▶ Try the interactive demo](demo/index.html)** — adjust growth, WACC, and
terminal value assumptions and watch the valuation update live, entirely in
your browser.

## Features

- **Core engine** (`dcf_model_generator.engine`) — revenue projection with a
  fading growth curve, WACC via CAPM, Gordon Growth or exit-multiple terminal
  value, and a WACC × terminal-growth sensitivity grid.
- **Two ways to get data in:**
  - Manual JSON/CSV templates you fill in yourself (`dcf template`)
  - Live fundamentals for any public ticker via `yfinance`
- **CLI** (`dcf`) — run a valuation from a ticker or a file, print a summary,
  optionally export to Excel.
- **Excel export** — a real, formula-driven workbook (not a snapshot of
  numbers): Assumptions, DCF Model, and Sensitivity sheets, following standard
  financial-model conventions (blue inputs, yellow key-assumption cells,
  black formulas).
- **Interactive browser demo** — a single static HTML file with no backend,
  suitable for GitHub Pages. Supports importing/exporting your assumptions as
  JSON (compatible with the CLI's `--input` flag) and exporting a quick
  value-only Excel snapshot.
- **Test suite** — 32 pytest tests covering the engine, data loading, and the
  Excel export.

## Installation

```bash
git clone https://github.com/<your-username>/dcf-model-generator.git
cd dcf-model-generator
pip install -e .
```

Or just install the dependencies and run things as scripts:

```bash
pip install -r requirements.txt
```

## CLI usage

Generate a fillable input template:

```bash
dcf template --output my_company.json
```

Run a DCF from that template and export a workbook:

```bash
dcf run --input my_company.json --export my_company_dcf.xlsx
```

Run a DCF straight from a public ticker (financials pulled via `yfinance`):

```bash
dcf run --ticker AAPL --export aapl_dcf.xlsx
```

Override individual assumptions from the command line without editing the
file:

```bash
dcf run --ticker AAPL --growth-start 0.12 --terminal-growth 0.03 --tax-rate 0.24 --export aapl_dcf.xlsx
```

Run `dcf run --help` for the full list of overridable flags.

## Library usage

```python
from dcf_model_generator import CompanyFinancials, Assumptions, run_dcf, export_dcf_to_excel

company = CompanyFinancials(
    name="Happy Hour Co",
    revenue=120.0,
    ebit=25.0,
    da=8.0,
    capex=10.0,
    cash_and_investments=20.0,
    total_debt=50.0,
    shares_outstanding=12.0,
    market_cap=220.0,
    beta=1.1,
)
assumptions = Assumptions(projection_years=5, terminal_growth_rate=0.025)

result = run_dcf(company, assumptions)
print(f"Implied share price: ${result.implied_share_price:.2f}")

export_dcf_to_excel(result, "happy_hour_co_dcf.xlsx")
```

## How the model works

1. **Revenue** grows at a rate that fades linearly from `revenue_growth_start`
   in Year 1 to `revenue_growth_end` (or the terminal growth rate, if
   unspecified) by the final projection year.
2. **EBIT** is revenue times a margin (historical margin by default).
3. **Unlevered free cash flow** = `EBIT × (1 − tax rate) + D&A − Capex − ΔNWC`.
4. **WACC** is computed via CAPM for the cost of equity, blended with an
   after-tax cost of debt, weighted by market value where available (book
   value / a conservative 80/20 default otherwise).
5. **Terminal value** is either Gordon Growth (`FCF × (1+g) / (WACC − g)`) or
   an exit EV/EBITDA multiple.
6. Cash flows and terminal value are discounted to the present, summed into
   **enterprise value**, then bridged to **equity value** and an **implied
   share price** by subtracting net debt and minority interest and dividing
   by diluted shares.

This is a simplified, single-scenario operating model (flat margins, a single
growth-fade curve, no debt schedule) — it's meant as a fast, auditable
starting point, not a substitute for a full three-statement model.

## Hosting the demo on GitHub Pages

A workflow at `.github/workflows/pages.yml` deploys `demo/index.html` to
GitHub Pages automatically on every push to `main`. One-time setup after
pushing this repo: go to **Settings → Pages** and set **Source** to
**"GitHub Actions"**. After that, any change under `demo/` redeploys
automatically — no manual build step.

## Browser demo ↔ CLI round-trip

The demo (`demo/index.html`) lets you explore assumptions live with sliders,
then:

- **Export JSON** saves your current inputs in the same schema `dcf run --input`
  expects — including a `wacc_override`, since the demo lets you set WACC
  directly rather than deriving it from CAPM inputs. `Assumptions.wacc_override`
  (in both the Python engine and the Excel export's WACC formula) honors this,
  so re-running the exported file through the CLI reproduces the exact same
  price.
- **Import JSON** loads a file back into the sliders — either one you
  exported, or a hand-filled `dcf template`.
- **Export Excel (snapshot)** writes a quick `.xlsx` with your current numbers
  via a client-side library. This is a **value snapshot, not a formula-linked
  model** — cells don't recalculate if you change one. For the real
  formula-driven workbook (the one validated against LibreOffice with zero
  formula errors), export your assumptions to JSON from the demo and run
  `dcf run --input your_file.json --export model.xlsx`.

## Project layout

```
dcf_model_generator/
  models.py         # CompanyFinancials, Assumptions, DCFResult dataclasses
  engine.py         # projection, WACC, terminal value, discounting, sensitivity
  data_sources.py   # manual JSON/CSV loaders + yfinance fetcher
  excel_export.py   # formula-driven .xlsx builder
  cli.py            # `dcf` command-line entry point
tests/              # pytest suite
demo/index.html     # standalone interactive browser demo
examples/           # sample input template
```

## Testing

```bash
pip install -e ".[dev]"
pytest -v
```

## Disclaimer

This tool is for educational and modeling purposes only. It is not financial
advice, and no output from it should be relied on for actual investment
decisions without independent verification.

## License

MIT — see [LICENSE](LICENSE).
