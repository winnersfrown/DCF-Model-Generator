import pytest

from dcf_model_generator.models import Assumptions, CompanyFinancials
from dcf_model_generator.engine import (
    project_financials,
    calculate_wacc,
    calculate_terminal_value,
    discount_cash_flows,
    run_dcf,
    sensitivity_table,
)


@pytest.fixture
def company():
    return CompanyFinancials(
        name="Test Co",
        ticker="TST",
        revenue=100.0,
        ebit=20.0,
        da=8.0,
        capex=10.0,
        cash_and_investments=15.0,
        total_debt=40.0,
        minority_interest=0.0,
        shares_outstanding=10.0,
        market_cap=180.0,
        beta=1.2,
    )


@pytest.fixture
def assumptions():
    return Assumptions(
        projection_years=5,
        revenue_growth_start=0.10,
        revenue_growth_end=0.03,
        tax_rate=0.25,
        nwc_pct_revenue=0.02,
        risk_free_rate=0.04,
        equity_risk_premium=0.05,
        cost_of_debt=0.06,
        terminal_growth_rate=0.03,
    )


def test_ebit_margin_derived_on_init():
    c = CompanyFinancials(name="X", revenue=200.0, ebit=40.0)
    assert c.ebit_margin == pytest.approx(0.2)


def test_net_debt():
    c = CompanyFinancials(name="X", total_debt=100.0, cash_and_investments=30.0)
    assert c.net_debt == 70.0


def test_growth_schedule_fades_linearly():
    a = Assumptions(projection_years=5, revenue_growth_start=0.10, revenue_growth_end=0.02)
    sched = a.growth_schedule()
    assert len(sched) == 5
    assert sched[0] == pytest.approx(0.10)
    assert sched[-1] == pytest.approx(0.02)
    # Monotonically decreasing (fading down)
    assert all(sched[i] >= sched[i + 1] for i in range(len(sched) - 1))


def test_growth_schedule_single_year():
    a = Assumptions(projection_years=1, revenue_growth_start=0.07)
    assert a.growth_schedule() == [0.07]


def test_growth_schedule_respects_overrides():
    a = Assumptions(projection_years=3, revenue_growth_overrides=[0.1, 0.08])
    sched = a.growth_schedule()
    assert sched == [0.1, 0.08, 0.08]  # last override repeats to fill


def test_project_financials_revenue_compounds(company, assumptions):
    rows = project_financials(company, assumptions)
    assert len(rows) == 5
    # Revenue should grow monotonically since all growth rates are positive
    revs = [r.revenue for r in rows]
    assert all(revs[i] < revs[i + 1] for i in range(len(revs) - 1))
    # First year revenue matches manual calc
    expected_year1 = company.revenue * (1 + assumptions.growth_schedule()[0])
    assert rows[0].revenue == pytest.approx(expected_year1)


def test_project_financials_fcf_formula(company, assumptions):
    rows = project_financials(company, assumptions)
    for row in rows:
        expected = row.nopat + row.da - row.capex - row.delta_nwc
        assert row.unlevered_fcf == pytest.approx(expected)


def test_calculate_wacc_uses_market_cap_weights(company, assumptions):
    info = calculate_wacc(company, assumptions)
    total_capital = company.market_cap + company.total_debt
    assert info["equity_weight"] == pytest.approx(company.market_cap / total_capital)
    assert info["debt_weight"] == pytest.approx(company.total_debt / total_capital)
    assert 0 < info["wacc"] < info["cost_of_equity"]  # blended rate is below pure cost of equity


def test_calculate_wacc_falls_back_without_market_data(assumptions):
    c = CompanyFinancials(name="NoMarket", revenue=100, ebit=20)
    info = calculate_wacc(c, assumptions)
    assert info["equity_weight"] == pytest.approx(0.8)
    assert info["debt_weight"] == pytest.approx(0.2)


def test_calculate_wacc_respects_target_debt_weight(company):
    a = Assumptions(target_debt_weight=0.4)
    info = calculate_wacc(company, a)
    assert info["debt_weight"] == pytest.approx(0.4)
    assert info["equity_weight"] == pytest.approx(0.6)


def test_terminal_value_gordon_growth(company, assumptions):
    rows = project_financials(company, assumptions)
    wacc = calculate_wacc(company, assumptions)["wacc"]
    tv = calculate_terminal_value(rows[-1], wacc, assumptions)
    expected = rows[-1].unlevered_fcf * (1 + assumptions.terminal_growth_rate) / (
        wacc - assumptions.terminal_growth_rate
    )
    assert tv == pytest.approx(expected)


def test_terminal_value_raises_when_wacc_below_growth(company, assumptions):
    rows = project_financials(company, assumptions)
    with pytest.raises(ValueError):
        calculate_terminal_value(rows[-1], wacc=0.02, assumptions=assumptions)


def test_terminal_value_exit_multiple(company, assumptions):
    a = dataclass_replace(assumptions, terminal_method="exit_multiple", exit_ev_ebitda_multiple=8.0)
    rows = project_financials(company, a)
    wacc = calculate_wacc(company, a)["wacc"]
    tv = calculate_terminal_value(rows[-1], wacc, a)
    expected_ebitda = rows[-1].ebit + rows[-1].da
    assert tv == pytest.approx(expected_ebitda * 8.0)


def test_terminal_value_exit_multiple_requires_multiple(company, assumptions):
    a = dataclass_replace(assumptions, terminal_method="exit_multiple")
    rows = project_financials(company, a)
    wacc = calculate_wacc(company, a)["wacc"]
    with pytest.raises(ValueError):
        calculate_terminal_value(rows[-1], wacc, a)


def test_discount_cash_flows_matches_manual_sum(company, assumptions):
    rows = project_financials(company, assumptions)
    wacc = 0.09
    pv = discount_cash_flows(rows, wacc)
    expected = sum(row.unlevered_fcf / (1.09 ** row.year) for row in rows)
    assert pv == pytest.approx(expected)


def test_run_dcf_end_to_end(company, assumptions):
    result = run_dcf(company, assumptions)
    assert result.enterprise_value == pytest.approx(result.pv_of_fcf + result.pv_of_terminal_value)
    expected_equity = (
        result.enterprise_value - company.total_debt + company.cash_and_investments - company.minority_interest
    )
    assert result.equity_value == pytest.approx(expected_equity)
    assert result.implied_share_price == pytest.approx(result.equity_value / company.shares_outstanding)
    assert result.implied_share_price > 0


def test_run_dcf_without_sensitivity_is_faster_and_omits_table(company, assumptions):
    result = run_dcf(company, assumptions, with_sensitivity=False)
    assert result.sensitivity is None


def test_sensitivity_table_shape(company, assumptions):
    table = sensitivity_table(company, assumptions, steps=2)
    assert len(table["wacc"]) == 5
    assert len(table["growth"]) == 5
    assert len(table["grid"]) == 5
    assert all(len(row) == 5 for row in table["grid"])


def test_sensitivity_table_handles_wacc_below_growth(company, assumptions):
    # Force a wide-enough delta that some wacc values fall below growth values
    table = sensitivity_table(company, assumptions, wacc_delta=0.03, growth_delta=0.03, steps=2)
    flat = [v for row in table["grid"] for v in row]
    assert any(v is None for v in flat)  # at least one undefined cell expected
    assert any(v is not None for v in flat)  # but not all of them


def test_zero_shares_outstanding_does_not_crash():
    c = CompanyFinancials(name="Weird", revenue=100, ebit=20, shares_outstanding=0)
    a = Assumptions()
    result = run_dcf(c, a, with_sensitivity=False)
    assert result.implied_share_price == 0.0


def dataclass_replace(obj, **kwargs):
    import dataclasses
    return dataclasses.replace(obj, **kwargs)
