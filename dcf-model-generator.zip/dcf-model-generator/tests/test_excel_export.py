from openpyxl import load_workbook

from dcf_model_generator.models import Assumptions, CompanyFinancials
from dcf_model_generator.engine import run_dcf
from dcf_model_generator.excel_export import export_dcf_to_excel


def _sample_result():
    company = CompanyFinancials(
        name="Happy Hour Co",
        ticker="HHC",
        revenue=120.0,
        ebit=25.0,
        da=8.0,
        capex=10.0,
        cash_and_investments=20.0,
        total_debt=50.0,
        shares_outstanding=12.0,
        market_cap=220.0,
        beta=1.1,
    )
    assumptions = Assumptions(projection_years=5, terminal_growth_rate=0.025)
    return run_dcf(company, assumptions)


def test_export_creates_expected_sheets(tmp_path):
    result = _sample_result()
    path = tmp_path / "model.xlsx"
    export_dcf_to_excel(result, str(path))

    wb = load_workbook(str(path))
    assert set(wb.sheetnames) == {"Assumptions", "DCF Model", "Sensitivity"}


def test_export_cells_contain_formulas_not_hardcoded_values(tmp_path):
    result = _sample_result()
    path = tmp_path / "model.xlsx"
    export_dcf_to_excel(result, str(path))

    wb = load_workbook(str(path))  # formulas mode (default) -- reads formula strings
    ws = wb["DCF Model"]

    # Revenue in the first projection column should be a formula, not a number
    found_formula = False
    for row in ws.iter_rows():
        for cell in row:
            if isinstance(cell.value, str) and cell.value.startswith("="):
                found_formula = True
                break
        if found_formula:
            break
    assert found_formula, "Expected at least one formula cell in the DCF Model sheet"


def test_export_assumptions_sheet_has_key_inputs(tmp_path):
    result = _sample_result()
    path = tmp_path / "model.xlsx"
    export_dcf_to_excel(result, str(path))

    wb = load_workbook(str(path))
    ws = wb["Assumptions"]
    all_values = [cell.value for row in ws.iter_rows() for cell in row]
    assert "Revenue" in all_values
    assert "Terminal Growth Rate (Gordon Growth)" in all_values


def test_export_handles_single_projection_year(tmp_path):
    company = CompanyFinancials(name="OneYear Co", revenue=50, ebit=10, shares_outstanding=5)
    assumptions = Assumptions(projection_years=1, revenue_growth_start=0.05, terminal_growth_rate=0.02)
    result = run_dcf(company, assumptions)
    path = tmp_path / "one_year.xlsx"
    export_dcf_to_excel(result, str(path))
    wb = load_workbook(str(path))
    assert "DCF Model" in wb.sheetnames
