import json
import os

import pytest

from dcf_model_generator.data_sources import (
    DataSourceError,
    load_manual_csv,
    load_manual_json,
    write_json_template,
)


def test_write_and_load_json_template(tmp_path):
    path = tmp_path / "template.json"
    write_json_template(str(path))
    assert path.exists()

    company, assumptions = load_manual_json(str(path))
    assert company.name == "Example Co"
    assert company.revenue == 500.0
    assert assumptions.projection_years == 5


def test_load_manual_json_missing_name_raises(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text(json.dumps({"company": {"revenue": 100}}))
    with pytest.raises(DataSourceError):
        load_manual_json(str(path))


def test_load_manual_json_ignores_unknown_keys(tmp_path):
    path = tmp_path / "extra.json"
    path.write_text(json.dumps({
        "company": {"name": "X", "revenue": 50, "made_up_field": 123},
        "assumptions": {"tax_rate": 0.3, "nonexistent": "abc"},
    }))
    company, assumptions = load_manual_json(str(path))
    assert company.name == "X"
    assert company.revenue == 50
    assert assumptions.tax_rate == 0.3


def test_load_manual_csv_roundtrip(tmp_path):
    path = tmp_path / "input.csv"
    path.write_text(
        "section,field,value\n"
        "company,name,Happy Hour Co\n"
        "company,revenue,120.0\n"
        "company,ebit,25.0\n"
        "assumptions,terminal_growth_rate,0.025\n"
        "assumptions,projection_years,7\n"
    )
    company, assumptions = load_manual_csv(str(path))
    assert company.name == "Happy Hour Co"
    assert company.revenue == 120.0
    assert company.ebit == 25.0
    assert assumptions.terminal_growth_rate == 0.025
    assert assumptions.projection_years == 7


def test_load_manual_csv_missing_columns_raises(tmp_path):
    path = tmp_path / "bad.csv"
    path.write_text("a,b,c\n1,2,3\n")
    with pytest.raises(DataSourceError):
        load_manual_csv(str(path))


def test_load_manual_csv_missing_name_raises(tmp_path):
    path = tmp_path / "noname.csv"
    path.write_text("section,field,value\ncompany,revenue,100\n")
    with pytest.raises(DataSourceError):
        load_manual_csv(str(path))
