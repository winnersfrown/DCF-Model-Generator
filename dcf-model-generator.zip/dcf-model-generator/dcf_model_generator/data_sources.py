"""Ways to get a CompanyFinancials + Assumptions pair into the engine:

1. `load_manual_json` / `load_manual_csv` -- read a template the user filled in.
2. `fetch_from_yfinance` -- pull recent fundamentals for a public ticker.

Both paths return the same (CompanyFinancials, Assumptions) tuple so the rest
of the package doesn't need to know where the numbers came from.
"""
from __future__ import annotations

import csv
import json
from dataclasses import fields
from typing import Tuple

from .models import Assumptions, CompanyFinancials


class DataSourceError(RuntimeError):
    """Raised when a data source can't produce usable financials."""


def _build_from_dict(data: dict) -> Tuple[CompanyFinancials, Assumptions]:
    company_fields = {f.name for f in fields(CompanyFinancials)}
    assumptions_fields = {f.name for f in fields(Assumptions)}

    company_kwargs = {k: v for k, v in data.get("company", {}).items() if k in company_fields}
    assumptions_kwargs = {
        k: v for k, v in data.get("assumptions", {}).items() if k in assumptions_fields
    }

    if "name" not in company_kwargs:
        raise DataSourceError("Input is missing required field: company.name")

    company = CompanyFinancials(**company_kwargs)
    assumptions = Assumptions(**assumptions_kwargs)
    return company, assumptions


def load_manual_json(path: str) -> Tuple[CompanyFinancials, Assumptions]:
    """Load a company + assumptions template from a JSON file.

    Expected shape:
    {
      "company": {"name": "...", "revenue": ..., "ebit": ..., ...},
      "assumptions": {"projection_years": 5, "terminal_growth_rate": 0.025, ...}
    }
    Unknown keys are ignored; missing keys fall back to dataclass defaults.
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return _build_from_dict(data)


def load_manual_csv(path: str) -> Tuple[CompanyFinancials, Assumptions]:
    """Load from a two-column CSV of `section,field,value` rows, e.g.:

    section,field,value
    company,name,Happy Hour Co
    company,revenue,120.0
    assumptions,terminal_growth_rate,0.025
    """
    data = {"company": {}, "assumptions": {}}
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        required = {"section", "field", "value"}
        if not required.issubset(reader.fieldnames or []):
            raise DataSourceError(
                f"CSV must have columns {sorted(required)}, got {reader.fieldnames}"
            )
        for row in reader:
            section, field_name, raw_value = row["section"].strip(), row["field"].strip(), row["value"]
            if section not in data:
                continue
            data[section][field_name] = _coerce(raw_value)
    return _build_from_dict(data)


def _coerce(raw_value: str):
    """Best-effort string -> number/bool coercion for CSV values."""
    value = raw_value.strip()
    if value == "":
        return None
    lowered = value.lower()
    if lowered in ("true", "false"):
        return lowered == "true"
    try:
        if "." in value or "e" in lowered:
            return float(value)
        return int(value)
    except ValueError:
        try:
            return float(value)
        except ValueError:
            return value


def write_json_template(path: str) -> None:
    """Write a fillable JSON template with example values and inline comments
    (as a `_notes` key, since JSON has no native comment syntax).
    """
    template = {
        "_notes": (
            "Fill in the `company` section with actual historical financials "
            "(most recent fiscal year, in a consistent currency unit e.g. millions). "
            "The `assumptions` section controls the forecast -- every field has a "
            "reasonable default if omitted, so only override what you have a view on."
        ),
        "company": {
            "name": "Example Co",
            "ticker": "EX",
            "revenue": 500.0,
            "ebit": 90.0,
            "da": 20.0,
            "capex": 25.0,
            "net_working_capital": 40.0,
            "cash_and_investments": 60.0,
            "total_debt": 150.0,
            "minority_interest": 0.0,
            "shares_outstanding": 100.0,
            "market_cap": 900.0,
            "beta": 1.1,
        },
        "assumptions": {
            "projection_years": 5,
            "revenue_growth_start": 0.08,
            "revenue_growth_end": 0.03,
            "tax_rate": 0.21,
            "nwc_pct_revenue": 0.02,
            "risk_free_rate": 0.042,
            "equity_risk_premium": 0.05,
            "cost_of_debt": 0.05,
            "terminal_method": "gordon",
            "terminal_growth_rate": 0.025,
        },
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(template, f, indent=2)


def fetch_from_yfinance(ticker: str) -> Tuple[CompanyFinancials, Assumptions]:
    """Pull recent fundamentals for a public ticker via yfinance and build a
    best-effort CompanyFinancials. Assumptions are left at their sensible
    defaults (based on the company's own historical margins where available)
    since forward growth/margin views are inherently a judgment call.

    Raises DataSourceError if the ticker can't be resolved or yfinance isn't
    reachable (e.g. no network access in this environment).
    """
    try:
        import yfinance as yf
    except ImportError as exc:
        raise DataSourceError(
            "yfinance is not installed. Install it with `pip install yfinance`."
        ) from exc

    try:
        tk = yf.Ticker(ticker)
        info = tk.info or {}
        financials = tk.financials  # annual income statement
        balance_sheet = tk.balance_sheet
        cashflow = tk.cashflow
    except Exception as exc:  # network errors, rate limits, bad ticker, etc.
        raise DataSourceError(f"Could not fetch data for '{ticker}': {exc}") from exc

    if not info or info.get("regularMarketPrice") is None and financials.empty:
        raise DataSourceError(f"No data returned for ticker '{ticker}'.")

    def _latest(df, *row_names):
        for name in row_names:
            if name in df.index:
                series = df.loc[name].dropna()
                if not series.empty:
                    return float(series.iloc[0])
        return 0.0

    revenue = _latest(financials, "Total Revenue")
    ebit = _latest(financials, "EBIT", "Operating Income")
    da = _latest(cashflow, "Depreciation And Amortization", "Depreciation")
    capex = abs(_latest(cashflow, "Capital Expenditure", "Capital Expenditures"))
    total_debt = _latest(balance_sheet, "Total Debt")
    cash = _latest(balance_sheet, "Cash And Cash Equivalents", "Cash")

    shares_outstanding = info.get("sharesOutstanding") or 1.0
    market_cap = info.get("marketCap")
    beta = info.get("beta")

    # Revenue in yfinance financials is in absolute currency units; convert
    # to millions for readability/consistency with the manual template.
    scale = 1_000_000
    company = CompanyFinancials(
        name=info.get("shortName") or ticker,
        ticker=ticker.upper(),
        revenue=revenue / scale,
        ebit=ebit / scale,
        da=da / scale,
        capex=capex / scale,
        cash_and_investments=cash / scale,
        total_debt=total_debt / scale,
        shares_outstanding=shares_outstanding / scale,
        market_cap=(market_cap / scale) if market_cap else None,
        beta=beta,
    )
    assumptions = Assumptions()
    return company, assumptions
