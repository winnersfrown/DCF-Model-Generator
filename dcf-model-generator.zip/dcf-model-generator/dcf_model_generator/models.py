"""Data structures shared across the DCF engine, data sources, CLI, and Excel export."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import List, Optional


@dataclass
class CompanyFinancials:
    """Baseline (most recent actual/TTM) financials used as the jumping-off point
    for the projection. All monetary values are in the same currency unit
    (e.g. millions) -- callers must be consistent.
    """

    name: str
    ticker: Optional[str] = None
    currency: str = "USD"

    revenue: float = 0.0
    ebit: float = 0.0
    ebit_margin: Optional[float] = None  # derived if not supplied

    da: float = 0.0                 # depreciation & amortization
    capex: float = 0.0              # capital expenditures (positive number)
    net_working_capital: float = 0.0

    cash_and_investments: float = 0.0
    total_debt: float = 0.0
    minority_interest: float = 0.0
    shares_outstanding: float = 1.0

    # Market inputs used for WACC, if known
    market_cap: Optional[float] = None
    beta: Optional[float] = None

    def __post_init__(self):
        if self.ebit_margin is None and self.revenue:
            self.ebit_margin = self.ebit / self.revenue

    @property
    def net_debt(self) -> float:
        return self.total_debt - self.cash_and_investments


@dataclass
class Assumptions:
    """All forward-looking assumptions that drive the projection, discount rate,
    and terminal value. Sensible finance-textbook defaults are provided so a
    quick run only needs a ticker/company name, but every field is meant to be
    overridden.
    """

    projection_years: int = 5

    # Revenue growth: first-year growth rate, fading linearly down to
    # `terminal_growth_rate` by the final projection year (a common,
    # defensible simplification of a full operating model).
    revenue_growth_start: float = 0.08
    revenue_growth_end: Optional[float] = None  # defaults to terminal_growth_rate

    # Margins / reinvestment, held flat across the projection unless the
    # caller supplies explicit per-year overrides.
    ebit_margin: Optional[float] = None       # defaults to CompanyFinancials.ebit_margin
    tax_rate: float = 0.21
    da_pct_revenue: Optional[float] = None    # defaults to historical D&A/revenue
    capex_pct_revenue: Optional[float] = None # defaults to historical capex/revenue
    nwc_pct_revenue: float = 0.02             # incremental NWC as % of revenue *increase*

    # Discount rate (WACC) inputs
    risk_free_rate: float = 0.042
    equity_risk_premium: float = 0.05
    beta: Optional[float] = None              # defaults to CompanyFinancials.beta or 1.0
    cost_of_debt: float = 0.05
    target_debt_weight: Optional[float] = None  # defaults to book-value based weight

    # Terminal value
    terminal_method: str = "gordon"  # "gordon" or "exit_multiple"
    terminal_growth_rate: float = 0.025
    exit_ev_ebitda_multiple: Optional[float] = None

    # Optional explicit per-year overrides (index 0 = first projection year)
    revenue_growth_overrides: List[float] = field(default_factory=list)

    def growth_schedule(self) -> List[float]:
        """Return the per-year revenue growth rate for each projection year,
        fading linearly from `revenue_growth_start` to `revenue_growth_end`
        unless explicit overrides are supplied.
        """
        if self.revenue_growth_overrides:
            rates = list(self.revenue_growth_overrides)
            if len(rates) < self.projection_years:
                rates += [rates[-1]] * (self.projection_years - len(rates))
            return rates[: self.projection_years]

        end = self.revenue_growth_end
        if end is None:
            end = self.terminal_growth_rate
        n = self.projection_years
        if n == 1:
            return [self.revenue_growth_start]
        step = (end - self.revenue_growth_start) / (n - 1)
        return [self.revenue_growth_start + step * i for i in range(n)]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ProjectionRow:
    year: int
    revenue: float
    revenue_growth: float
    ebit: float
    nopat: float
    da: float
    capex: float
    delta_nwc: float
    unlevered_fcf: float


@dataclass
class DCFResult:
    company: CompanyFinancials
    assumptions: Assumptions
    projections: List[ProjectionRow]

    wacc: float
    cost_of_equity: float
    equity_weight: float
    debt_weight: float

    terminal_value_undiscounted: float
    pv_of_fcf: float
    pv_of_terminal_value: float
    enterprise_value: float
    equity_value: float
    implied_share_price: float

    sensitivity: Optional[dict] = None  # {"wacc": [...], "growth": [...], "grid": [[...]]}
