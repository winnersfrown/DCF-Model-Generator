"""dcf-model-generator: a small, testable engine for building discounted cash
flow valuations, with CLI, Excel export, and yfinance data-fetching support.
"""
from .models import Assumptions, CompanyFinancials, DCFResult, ProjectionRow
from .engine import run_dcf, project_financials, calculate_wacc, calculate_terminal_value
from .data_sources import load_manual_json, load_manual_csv, fetch_from_yfinance, write_json_template
from .excel_export import export_dcf_to_excel

__version__ = "0.1.0"

__all__ = [
    "Assumptions",
    "CompanyFinancials",
    "DCFResult",
    "ProjectionRow",
    "run_dcf",
    "project_financials",
    "calculate_wacc",
    "calculate_terminal_value",
    "load_manual_json",
    "load_manual_csv",
    "fetch_from_yfinance",
    "write_json_template",
    "export_dcf_to_excel",
    "__version__",
]
