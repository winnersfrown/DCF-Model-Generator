"""The core DCF valuation engine.

Every function here is pure (no I/O) and operates purely on the
CompanyFinancials / Assumptions dataclasses, which makes it straightforward
to unit test and to reuse from the CLI, the Excel exporter, or a notebook.
"""
from __future__ import annotations

from typing import List

from .models import Assumptions, CompanyFinancials, DCFResult, ProjectionRow


def project_financials(
    company: CompanyFinancials, assumptions: Assumptions
) -> List[ProjectionRow]:
    """Build the year-by-year unlevered free cash flow projection."""
    ebit_margin = assumptions.ebit_margin
    if ebit_margin is None:
        ebit_margin = company.ebit_margin if company.ebit_margin is not None else 0.15

    da_pct = assumptions.da_pct_revenue
    if da_pct is None:
        da_pct = (company.da / company.revenue) if company.revenue else 0.03

    capex_pct = assumptions.capex_pct_revenue
    if capex_pct is None:
        capex_pct = (company.capex / company.revenue) if company.revenue else 0.04

    growth_schedule = assumptions.growth_schedule()

    rows: List[ProjectionRow] = []
    prior_revenue = company.revenue
    for i, growth in enumerate(growth_schedule, start=1):
        revenue = prior_revenue * (1 + growth)
        ebit = revenue * ebit_margin
        nopat = ebit * (1 - assumptions.tax_rate)
        da = revenue * da_pct
        capex = revenue * capex_pct
        delta_nwc = (revenue - prior_revenue) * assumptions.nwc_pct_revenue
        ufcf = nopat + da - capex - delta_nwc

        rows.append(
            ProjectionRow(
                year=i,
                revenue=revenue,
                revenue_growth=growth,
                ebit=ebit,
                nopat=nopat,
                da=da,
                capex=capex,
                delta_nwc=delta_nwc,
                unlevered_fcf=ufcf,
            )
        )
        prior_revenue = revenue

    return rows


def calculate_cost_of_equity(assumptions: Assumptions, company: CompanyFinancials) -> float:
    beta = assumptions.beta if assumptions.beta is not None else (company.beta or 1.0)
    return assumptions.risk_free_rate + beta * assumptions.equity_risk_premium


def calculate_wacc(company: CompanyFinancials, assumptions: Assumptions) -> dict:
    """Returns a dict with wacc, cost_of_equity, equity_weight, debt_weight."""
    cost_of_equity = calculate_cost_of_equity(assumptions, company)

    equity_value_for_weights = company.market_cap if company.market_cap else (
        company.shares_outstanding * 0  # unknown; fall back below
    )

    if assumptions.target_debt_weight is not None:
        debt_weight = assumptions.target_debt_weight
        equity_weight = 1 - debt_weight
    elif company.market_cap and (company.market_cap + company.total_debt) > 0:
        total_capital = company.market_cap + company.total_debt
        equity_weight = company.market_cap / total_capital
        debt_weight = company.total_debt / total_capital
    else:
        # Conservative textbook default when no market data is available.
        equity_weight, debt_weight = 0.8, 0.2

    after_tax_cost_of_debt = assumptions.cost_of_debt * (1 - assumptions.tax_rate)
    wacc = equity_weight * cost_of_equity + debt_weight * after_tax_cost_of_debt

    return {
        "wacc": wacc,
        "cost_of_equity": cost_of_equity,
        "equity_weight": equity_weight,
        "debt_weight": debt_weight,
    }


def calculate_terminal_value(
    final_year_row: ProjectionRow,
    wacc: float,
    assumptions: Assumptions,
) -> float:
    """Undiscounted terminal value as of the end of the final projection year."""
    if assumptions.terminal_method == "exit_multiple":
        if not assumptions.exit_ev_ebitda_multiple:
            raise ValueError(
                "exit_ev_ebitda_multiple must be set when terminal_method='exit_multiple'"
            )
        ebitda = final_year_row.ebit + final_year_row.da
        return ebitda * assumptions.exit_ev_ebitda_multiple

    # Gordon growth (perpetuity growth) method
    g = assumptions.terminal_growth_rate
    if wacc <= g:
        raise ValueError(
            f"WACC ({wacc:.2%}) must exceed the terminal growth rate ({g:.2%}) "
            "for the Gordon growth formula to produce a finite, positive value."
        )
    next_year_fcf = final_year_row.unlevered_fcf * (1 + g)
    return next_year_fcf / (wacc - g)


def discount_cash_flows(rows: List[ProjectionRow], wacc: float) -> float:
    return sum(row.unlevered_fcf / ((1 + wacc) ** row.year) for row in rows)


def run_dcf(
    company: CompanyFinancials,
    assumptions: Assumptions,
    with_sensitivity: bool = True,
) -> DCFResult:
    """Run the full DCF: project cash flows, discount them, add terminal value,
    and bridge to an implied share price.
    """
    rows = project_financials(company, assumptions)

    wacc_info = calculate_wacc(company, assumptions)
    wacc = wacc_info["wacc"]

    terminal_value = calculate_terminal_value(rows[-1], wacc, assumptions)
    n = rows[-1].year

    pv_fcf = discount_cash_flows(rows, wacc)
    pv_terminal = terminal_value / ((1 + wacc) ** n)

    enterprise_value = pv_fcf + pv_terminal
    equity_value = (
        enterprise_value
        - company.total_debt
        + company.cash_and_investments
        - company.minority_interest
    )
    implied_share_price = (
        equity_value / company.shares_outstanding if company.shares_outstanding else 0.0
    )

    sensitivity = None
    if with_sensitivity:
        sensitivity = sensitivity_table(company, assumptions)

    return DCFResult(
        company=company,
        assumptions=assumptions,
        projections=rows,
        wacc=wacc,
        cost_of_equity=wacc_info["cost_of_equity"],
        equity_weight=wacc_info["equity_weight"],
        debt_weight=wacc_info["debt_weight"],
        terminal_value_undiscounted=terminal_value,
        pv_of_fcf=pv_fcf,
        pv_of_terminal_value=pv_terminal,
        enterprise_value=enterprise_value,
        equity_value=equity_value,
        implied_share_price=implied_share_price,
        sensitivity=sensitivity,
    )


def sensitivity_table(
    company: CompanyFinancials,
    assumptions: Assumptions,
    wacc_delta: float = 0.01,
    growth_delta: float = 0.005,
    steps: int = 2,
) -> dict:
    """Flex WACC and terminal growth rate around the base case and report the
    implied share price at each combination -- the standard DCF sensitivity
    grid. `steps` controls how many increments are shown on each side of the
    base case (steps=2 -> a 5x5 grid).
    """
    base_wacc = calculate_wacc(company, assumptions)["wacc"]
    base_growth = assumptions.terminal_growth_rate

    wacc_values = [
        base_wacc + wacc_delta * i for i in range(-steps, steps + 1)
    ]
    growth_values = [
        base_growth + growth_delta * i for i in range(-steps, steps + 1)
    ]

    grid = []
    for w in wacc_values:
        row_prices = []
        for g in growth_values:
            if w <= g:
                row_prices.append(None)  # Gordon growth formula is undefined here
                continue
            local_assumptions = _clone_with(assumptions, terminal_growth_rate=g)
            rows = project_financials(company, local_assumptions)
            try:
                tv = calculate_terminal_value(rows[-1], w, local_assumptions)
            except ValueError:
                row_prices.append(None)
                continue
            n = rows[-1].year
            pv_fcf = discount_cash_flows(rows, w)
            pv_tv = tv / ((1 + w) ** n)
            ev = pv_fcf + pv_tv
            eq_value = ev - company.total_debt + company.cash_and_investments - company.minority_interest
            price = eq_value / company.shares_outstanding if company.shares_outstanding else 0.0
            row_prices.append(price)
        grid.append(row_prices)

    return {"wacc": wacc_values, "growth": growth_values, "grid": grid}


def _clone_with(assumptions: Assumptions, **overrides) -> Assumptions:
    import dataclasses

    return dataclasses.replace(assumptions, **overrides)
