"""Command-line interface for dcf-model-generator.

Examples
--------
  dcf template --output assumptions.json
  dcf run --input assumptions.json --export output.xlsx
  dcf run --ticker AAPL --export aapl_dcf.xlsx
  dcf run --ticker AAPL --growth-start 0.12 --terminal-growth 0.03 --export aapl_dcf.xlsx
"""
from __future__ import annotations

import dataclasses
import sys

import click

from .data_sources import (
    DataSourceError,
    fetch_from_yfinance,
    load_manual_csv,
    load_manual_json,
    write_json_template,
)
from .engine import run_dcf
from .excel_export import export_dcf_to_excel


@click.group()
@click.version_option()
def main():
    """dcf-model-generator: build and export discounted cash flow models."""


@main.command()
@click.option("--output", "-o", default="assumptions_template.json", show_default=True,
              help="Where to write the fillable JSON template.")
def template(output):
    """Write a fillable JSON input template (company financials + assumptions)."""
    write_json_template(output)
    click.echo(f"Wrote template to {output}")


@main.command()
@click.option("--ticker", help="Public ticker to fetch financials for via yfinance (e.g. AAPL).")
@click.option("--input", "input_path", type=click.Path(exists=True),
              help="Path to a manual JSON or CSV input file (see `dcf template`).")
@click.option("--export", "export_path", type=click.Path(), default=None,
              help="Path to write a formula-driven Excel workbook (.xlsx).")
@click.option("--projection-years", type=int, default=None, help="Override number of forecast years.")
@click.option("--growth-start", type=float, default=None, help="Override Year 1 revenue growth rate (e.g. 0.08).")
@click.option("--growth-end", type=float, default=None, help="Override final-year revenue growth rate.")
@click.option("--terminal-growth", type=float, default=None, help="Override terminal (perpetuity) growth rate.")
@click.option("--tax-rate", type=float, default=None, help="Override tax rate.")
@click.option("--no-sensitivity", is_flag=True, help="Skip the WACC/growth sensitivity table (faster).")
def run(ticker, input_path, export_path, projection_years, growth_start, growth_end,
        terminal_growth, tax_rate, no_sensitivity):
    """Run a DCF valuation from a ticker or a manual input file and print the result."""
    if not ticker and not input_path:
        raise click.UsageError("Provide either --ticker or --input.")
    if ticker and input_path:
        raise click.UsageError("Provide only one of --ticker or --input, not both.")

    try:
        if ticker:
            company, assumptions = fetch_from_yfinance(ticker)
        elif input_path.endswith(".csv"):
            company, assumptions = load_manual_csv(input_path)
        else:
            company, assumptions = load_manual_json(input_path)
    except DataSourceError as exc:
        click.echo(f"Error loading data: {exc}", err=True)
        sys.exit(1)

    overrides = {}
    if projection_years is not None:
        overrides["projection_years"] = projection_years
    if growth_start is not None:
        overrides["revenue_growth_start"] = growth_start
    if growth_end is not None:
        overrides["revenue_growth_end"] = growth_end
    if terminal_growth is not None:
        overrides["terminal_growth_rate"] = terminal_growth
    if tax_rate is not None:
        overrides["tax_rate"] = tax_rate
    if overrides:
        assumptions = dataclasses.replace(assumptions, **overrides)

    result = run_dcf(company, assumptions, with_sensitivity=not no_sensitivity)

    _print_summary(result)

    if export_path:
        export_dcf_to_excel(result, export_path)
        click.echo(f"\nWrote Excel workbook to {export_path}")


def _print_summary(result):
    c, r = result.company, result
    click.echo(f"\n=== DCF Valuation: {c.name} ({c.ticker or 'n/a'}) ===")
    click.echo(f"{'Year':<6}{'Revenue':>12}{'EBIT':>12}{'UFCF':>12}")
    for row in r.projections:
        click.echo(f"{row.year:<6}{row.revenue:>12,.1f}{row.ebit:>12,.1f}{row.unlevered_fcf:>12,.1f}")

    click.echo(f"\nWACC:                 {r.wacc:.2%}")
    click.echo(f"Terminal Value:        {r.terminal_value_undiscounted:,.1f}")
    click.echo(f"PV of FCF:             {r.pv_of_fcf:,.1f}")
    click.echo(f"PV of Terminal Value:  {r.pv_of_terminal_value:,.1f}")
    click.echo(f"Enterprise Value:      {r.enterprise_value:,.1f}")
    click.echo(f"Equity Value:          {r.equity_value:,.1f}")
    click.echo(f"Implied Share Price:   ${r.implied_share_price:,.2f}")


if __name__ == "__main__":
    main()
