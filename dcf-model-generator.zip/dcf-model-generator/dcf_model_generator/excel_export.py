"""Export a DCF run to a formula-driven Excel workbook.

Follows standard financial-model conventions: blue font for hardcoded inputs,
black for formulas, yellow fill for key assumptions, parentheses for
negatives, and no hardcoded outputs -- every derived number is an Excel
formula that recalculates if you change an input cell.
"""
from __future__ import annotations

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .models import Assumptions, CompanyFinancials, DCFResult

BLUE = Font(color="0000FF")
BLACK = Font(color="000000")
BOLD = Font(bold=True)
BOLD_BLUE = Font(bold=True, color="0000FF")
HEADER_FONT = Font(bold=True, size=13, color="FFFFFF")
SECTION_FONT = Font(bold=True, size=11, color="FFFFFF")
YELLOW_FILL = PatternFill("solid", fgColor="FFFF00")
HEADER_FILL = PatternFill("solid", fgColor="1F3864")
SECTION_FILL = PatternFill("solid", fgColor="2E5395")
THIN = Side(style="thin", color="B7B7B7")
BORDER = Border(bottom=THIN)

CURRENCY_FMT = "$#,##0.0;($#,##0.0);-"
PCT_FMT = "0.0%;(0.0%);-"
MULT_FMT = "0.0x"
YEAR_FMT = "0"


def _section(ws, row, col, text, span=2):
    cell = ws.cell(row=row, column=col, value=text)
    cell.font = SECTION_FONT
    cell.fill = SECTION_FILL
    for c in range(col, col + span):
        ws.cell(row=row, column=c).fill = SECTION_FILL
    return row + 1


def _input_row(ws, row, label, value, fmt=None, col_label=2, col_value=3):
    ws.cell(row=row, column=col_label, value=label)
    cell = ws.cell(row=row, column=col_value, value=value)
    cell.font = BLUE
    cell.fill = YELLOW_FILL
    if fmt:
        cell.number_format = fmt
    return f"'{ws.title}'!${get_column_letter(col_value)}${row}"


def build_workbook(result: DCFResult) -> Workbook:
    wb = Workbook()
    ws_a = wb.active
    ws_a.title = "Assumptions"
    ws_m = wb.create_sheet("DCF Model")
    ws_s = wb.create_sheet("Sensitivity")

    refs = {}  # name -> fully-qualified cell reference string, for cross-sheet formulas

    # ---------------------------------------------------------------- #
    # Assumptions sheet
    # ---------------------------------------------------------------- #
    ws_a.column_dimensions["A"].width = 2
    ws_a.column_dimensions["B"].width = 34
    ws_a.column_dimensions["C"].width = 16
    ws_a.column_dimensions["D"].width = 46

    ws_a.merge_cells("B1:D1")
    ws_a["B1"] = f"DCF Model — {result.company.name}"
    ws_a["B1"].font = HEADER_FONT
    ws_a["B1"].fill = HEADER_FILL
    ws_a["B1"].alignment = Alignment(vertical="center")
    ws_a.row_dimensions[1].height = 24

    r = 3
    r = _section(ws_a, r, 2, "COMPANY FINANCIALS (most recent fiscal year)")
    company = result.company
    refs["revenue"] = _input_row(ws_a, r, "Revenue", company.revenue, CURRENCY_FMT); r += 1
    refs["ebit"] = _input_row(ws_a, r, "EBIT", company.ebit, CURRENCY_FMT); r += 1
    ws_a.cell(row=r, column=2, value="EBIT Margin (implied)")
    c = ws_a.cell(row=r, column=3, value=f"={refs['ebit']}/{refs['revenue']}")
    c.number_format = PCT_FMT
    refs["ebit_margin_implied"] = f"'Assumptions'!$C${r}"
    r += 1
    refs["da"] = _input_row(ws_a, r, "D&A", company.da, CURRENCY_FMT); r += 1
    refs["capex"] = _input_row(ws_a, r, "Capex", company.capex, CURRENCY_FMT); r += 1
    refs["cash"] = _input_row(ws_a, r, "Cash & Investments", company.cash_and_investments, CURRENCY_FMT); r += 1
    refs["total_debt"] = _input_row(ws_a, r, "Total Debt", company.total_debt, CURRENCY_FMT); r += 1
    refs["minority"] = _input_row(ws_a, r, "Minority Interest", company.minority_interest, CURRENCY_FMT); r += 1
    refs["shares"] = _input_row(ws_a, r, "Diluted Shares Outstanding", company.shares_outstanding, "#,##0.0"); r += 1
    refs["market_cap"] = _input_row(
        ws_a, r, "Market Cap (optional, for WACC weights)", company.market_cap or 0, CURRENCY_FMT
    ); r += 1
    r += 1

    r = _section(ws_a, r, 2, "FORECAST ASSUMPTIONS")
    a = result.assumptions
    refs["proj_years"] = _input_row(ws_a, r, "Projection Years", a.projection_years, YEAR_FMT); r += 1
    refs["growth_start"] = _input_row(ws_a, r, "Revenue Growth — Year 1", a.growth_schedule()[0], PCT_FMT); r += 1
    refs["growth_end"] = _input_row(
        ws_a, r, "Revenue Growth — Final Year", a.growth_schedule()[-1], PCT_FMT
    ); r += 1
    refs["ebit_margin"] = _input_row(
        ws_a, r, "Forecast EBIT Margin", a.ebit_margin if a.ebit_margin is not None else "", PCT_FMT
    )
    ws_a.cell(row=r, column=4, value="Leave blank to use implied historical margin above").font = Font(italic=True, size=9)
    r += 1
    refs["tax_rate"] = _input_row(ws_a, r, "Tax Rate", a.tax_rate, PCT_FMT); r += 1
    da_pct_default = a.da_pct_revenue if a.da_pct_revenue is not None else (company.da / company.revenue if company.revenue else 0)
    refs["da_pct"] = _input_row(ws_a, r, "D&A % of Revenue", da_pct_default, PCT_FMT); r += 1
    capex_pct_default = a.capex_pct_revenue if a.capex_pct_revenue is not None else (company.capex / company.revenue if company.revenue else 0)
    refs["capex_pct"] = _input_row(ws_a, r, "Capex % of Revenue", capex_pct_default, PCT_FMT); r += 1
    refs["nwc_pct"] = _input_row(ws_a, r, "Incremental NWC % of Revenue Growth", a.nwc_pct_revenue, PCT_FMT); r += 1
    r += 1

    r = _section(ws_a, r, 2, "DISCOUNT RATE (WACC)")
    refs["risk_free"] = _input_row(ws_a, r, "Risk-Free Rate", a.risk_free_rate, PCT_FMT); r += 1
    refs["erp"] = _input_row(ws_a, r, "Equity Risk Premium", a.equity_risk_premium, PCT_FMT); r += 1
    refs["beta"] = _input_row(ws_a, r, "Beta", a.beta if a.beta is not None else (company.beta or 1.0), "0.00"); r += 1
    refs["cost_of_debt"] = _input_row(ws_a, r, "Pre-Tax Cost of Debt", a.cost_of_debt, PCT_FMT); r += 1
    refs["debt_weight"] = _input_row(
        ws_a, r, "Target Debt Weight (blank = use market cap)",
        a.target_debt_weight if a.target_debt_weight is not None else "",
        PCT_FMT,
    ); r += 1
    r += 1

    r = _section(ws_a, r, 2, "TERMINAL VALUE")
    refs["terminal_growth"] = _input_row(ws_a, r, "Terminal Growth Rate (Gordon Growth)", a.terminal_growth_rate, PCT_FMT); r += 1
    refs["exit_multiple"] = _input_row(
        ws_a, r, "Exit EV/EBITDA Multiple (alt. method)",
        a.exit_ev_ebitda_multiple if a.exit_ev_ebitda_multiple is not None else "",
        MULT_FMT,
    ); r += 1
    ws_a.cell(
        row=r, column=2,
        value="Note: this workbook's formulas use the Gordon Growth terminal value. "
              "Switch to the exit multiple manually in 'DCF Model' if preferred.",
    ).font = Font(italic=True, size=9)

    # ---------------------------------------------------------------- #
    # DCF Model sheet
    # ---------------------------------------------------------------- #
    n = a.projection_years
    ws_m.column_dimensions["A"].width = 28
    for i in range(n + 1):
        ws_m.column_dimensions[get_column_letter(2 + i)].width = 14

    ws_m.merge_cells(f"A1:{get_column_letter(2 + n)}1")
    ws_m["A1"] = f"DCF Model — {company.name}: Projection & Valuation"
    ws_m["A1"].font = HEADER_FONT
    ws_m["A1"].fill = HEADER_FILL
    ws_m.row_dimensions[1].height = 24

    header_row = 3
    ws_m.cell(row=header_row, column=1, value="($ in millions)").font = Font(italic=True, size=9)
    for i in range(1, n + 1):
        col = 2 + i
        cell = ws_m.cell(row=header_row, column=col, value=f"Year {i}")
        cell.font = BOLD
        cell.border = BORDER
        cell.alignment = Alignment(horizontal="center")

    row_growth = header_row + 1
    row_revenue = row_growth + 1
    row_ebit = row_revenue + 1
    row_nopat = row_ebit + 1
    row_da = row_nopat + 1
    row_capex = row_da + 1
    row_nwc = row_capex + 1
    row_fcf = row_nwc + 1

    labels = {
        row_growth: "Revenue Growth %",
        row_revenue: "Revenue",
        row_ebit: "EBIT",
        row_nopat: "NOPAT",
        row_da: "(+) D&A",
        row_capex: "(–) Capex",
        row_nwc: "(–) Increase in NWC",
        row_fcf: "Unlevered Free Cash Flow",
    }
    for row, label in labels.items():
        c = ws_m.cell(row=row, column=1, value=label)
        if row == row_fcf:
            c.font = BOLD

    ebit_margin_cell = f"IF({refs['ebit_margin']}=\"\",{refs['ebit_margin_implied']},{refs['ebit_margin']})"

    for i in range(1, n + 1):
        col = get_column_letter(2 + i)
        prev_col = get_column_letter(1 + i)  # revenue col of prior period (or Assumptions revenue for i==1)

        # Growth: linear fade from growth_start to growth_end across n years
        if n == 1:
            growth_formula = f"={refs['growth_start']}"
        else:
            growth_formula = (
                f"={refs['growth_start']}+({refs['growth_end']}-{refs['growth_start']})"
                f"*({i}-1)/({refs['proj_years']}-1)"
            )
        ws_m[f"{col}{row_growth}"] = growth_formula
        ws_m[f"{col}{row_growth}"].number_format = PCT_FMT

        prior_revenue_ref = refs["revenue"] if i == 1 else f"{prev_col}{row_revenue}"
        ws_m[f"{col}{row_revenue}"] = f"={prior_revenue_ref}*(1+{col}{row_growth})"
        ws_m[f"{col}{row_revenue}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_ebit}"] = f"={col}{row_revenue}*({ebit_margin_cell})"
        ws_m[f"{col}{row_ebit}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_nopat}"] = f"={col}{row_ebit}*(1-{refs['tax_rate']})"
        ws_m[f"{col}{row_nopat}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_da}"] = f"={col}{row_revenue}*{refs['da_pct']}"
        ws_m[f"{col}{row_da}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_capex}"] = f"={col}{row_revenue}*{refs['capex_pct']}"
        ws_m[f"{col}{row_capex}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_nwc}"] = f"=({col}{row_revenue}-{prior_revenue_ref})*{refs['nwc_pct']}"
        ws_m[f"{col}{row_nwc}"].number_format = CURRENCY_FMT

        ws_m[f"{col}{row_fcf}"] = (
            f"={col}{row_nopat}+{col}{row_da}-{col}{row_capex}-{col}{row_nwc}"
        )
        ws_m[f"{col}{row_fcf}"].font = BOLD
        ws_m[f"{col}{row_fcf}"].number_format = CURRENCY_FMT

    last_col = get_column_letter(2 + n)
    fcf_range = f"C{row_fcf}:{last_col}{row_fcf}"
    year_header_range = f"C{header_row}:{last_col}{header_row}"

    # ---- WACC block ----
    r2 = row_fcf + 2
    r2 = _section(ws_m, r2, 1, "DISCOUNT RATE (WACC)", span=3)
    ws_m.cell(row=r2, column=1, value="Cost of Equity (CAPM)")
    ws_m.cell(row=r2, column=2, value=f"={refs['risk_free']}+{refs['beta']}*{refs['erp']}").number_format = PCT_FMT
    coe_cell = f"'DCF Model'!$B${r2}"
    r2 += 1
    ws_m.cell(row=r2, column=1, value="After-Tax Cost of Debt")
    ws_m.cell(row=r2, column=2, value=f"={refs['cost_of_debt']}*(1-{refs['tax_rate']})").number_format = PCT_FMT
    cod_cell = f"'DCF Model'!$B${r2}"
    r2 += 1
    ws_m.cell(row=r2, column=1, value="Equity Weight")
    ws_m.cell(
        row=r2, column=2,
        value=(
            f'=IF({refs["debt_weight"]}<>"",1-{refs["debt_weight"]},'
            f'IF({refs["market_cap"]}>0,{refs["market_cap"]}/({refs["market_cap"]}+{refs["total_debt"]}),0.8))'
        ),
    ).number_format = PCT_FMT
    ew_cell = f"'DCF Model'!$B${r2}"
    r2 += 1
    ws_m.cell(row=r2, column=1, value="Debt Weight")
    ws_m.cell(row=r2, column=2, value=f"=1-{ew_cell}").number_format = PCT_FMT
    dw_cell = f"'DCF Model'!$B${r2}"
    r2 += 1
    ws_m.cell(row=r2, column=1, value="WACC").font = BOLD
    wacc_cell_formula = f"={ew_cell}*{coe_cell}+{dw_cell}*{cod_cell}"
    wacc_cell = ws_m.cell(row=r2, column=2, value=wacc_cell_formula)
    wacc_cell.font = BOLD
    wacc_cell.number_format = PCT_FMT
    wacc_ref = f"'DCF Model'!$B${r2}"
    r2 += 2

    # ---- Terminal value & valuation bridge ----
    r2 = _section(ws_m, r2, 1, "VALUATION", span=3)
    ws_m.cell(row=r2, column=1, value="Terminal Value (Gordon Growth)")
    tv_formula = f"={last_col}{row_fcf}*(1+{refs['terminal_growth']})/({wacc_ref}-{refs['terminal_growth']})"
    ws_m.cell(row=r2, column=2, value=tv_formula).number_format = CURRENCY_FMT
    tv_cell = f"'DCF Model'!$B${r2}"
    r2 += 1

    ws_m.cell(row=r2, column=1, value="PV of Explicit-Period FCF")
    r2 += 1

    # Add a discount-factor row directly below the FCF row so PV of each
    # period's cash flow is a simple, auditable per-column formula.
    disc_row = row_fcf + 1
    ws_m.cell(row=disc_row, column=1, value="Discount Factor")
    for i in range(1, n + 1):
        col = get_column_letter(2 + i)
        ws_m[f"{col}{disc_row}"] = f"=1/(1+{wacc_ref})^{i}"
        ws_m[f"{col}{disc_row}"].number_format = "0.000"
    disc_range = f"C{disc_row}:{last_col}{disc_row}"

    ws_m.cell(row=r2 - 1, column=2, value=f"=SUMPRODUCT({fcf_range},{disc_range})").number_format = CURRENCY_FMT
    pv_fcf_cell = f"'DCF Model'!$B${r2 - 1}"

    ws_m.cell(row=r2, column=1, value="PV of Terminal Value")
    ws_m.cell(row=r2, column=2, value=f"={tv_cell}*{last_col}{disc_row}").number_format = CURRENCY_FMT
    pv_tv_cell = f"'DCF Model'!$B${r2}"
    r2 += 1

    ws_m.cell(row=r2, column=1, value="Enterprise Value").font = BOLD
    ev_cell_obj = ws_m.cell(row=r2, column=2, value=f"={pv_fcf_cell}+{pv_tv_cell}")
    ev_cell_obj.font = BOLD
    ev_cell_obj.number_format = CURRENCY_FMT
    ev_cell = f"'DCF Model'!$B${r2}"
    r2 += 1

    ws_m.cell(row=r2, column=1, value="(–) Total Debt")
    ws_m.cell(row=r2, column=2, value=f"=-{refs['total_debt']}").number_format = CURRENCY_FMT
    r2 += 1
    ws_m.cell(row=r2, column=1, value="(+) Cash & Investments")
    ws_m.cell(row=r2, column=2, value=f"={refs['cash']}").number_format = CURRENCY_FMT
    r2 += 1
    ws_m.cell(row=r2, column=1, value="(–) Minority Interest")
    ws_m.cell(row=r2, column=2, value=f"=-{refs['minority']}").number_format = CURRENCY_FMT
    r2 += 1

    ws_m.cell(row=r2, column=1, value="Equity Value").font = BOLD
    eq_formula = f"={ev_cell}-{refs['total_debt']}+{refs['cash']}-{refs['minority']}"
    eq_cell_obj = ws_m.cell(row=r2, column=2, value=eq_formula)
    eq_cell_obj.font = BOLD
    eq_cell_obj.number_format = CURRENCY_FMT
    eq_cell = f"'DCF Model'!$B${r2}"
    r2 += 1

    ws_m.cell(row=r2, column=1, value="Diluted Shares Outstanding")
    ws_m.cell(row=r2, column=2, value=f"={refs['shares']}").number_format = "#,##0.0"
    shares_ref = f"'DCF Model'!$B${r2}"
    r2 += 1

    ws_m.cell(row=r2, column=1, value="Implied Share Price").font = BOLD
    price_cell_obj = ws_m.cell(row=r2, column=2, value=f"={eq_cell}/{shares_ref}")
    price_cell_obj.font = BOLD
    price_cell_obj.number_format = "$#,##0.00"
    price_cell_obj.fill = YELLOW_FILL

    # ---------------------------------------------------------------- #
    # Sensitivity sheet: WACC (rows) x Terminal Growth (cols) -> price
    # ---------------------------------------------------------------- #
    ws_s.column_dimensions["A"].width = 24
    for i in range(6):
        ws_s.column_dimensions[get_column_letter(2 + i)].width = 13

    ws_s.merge_cells("A1:F1")
    ws_s["A1"] = "Sensitivity: Implied Share Price"
    ws_s["A1"].font = HEADER_FONT
    ws_s["A1"].fill = HEADER_FILL
    ws_s.row_dimensions[1].height = 22

    ws_s["A3"] = "WACC ↓ / Terminal Growth →"
    ws_s["A3"].font = BOLD

    sens = result.sensitivity or {"wacc": [], "growth": [], "grid": []}
    growth_values = sens["growth"]
    wacc_values = sens["wacc"]

    for j, g in enumerate(growth_values):
        col = get_column_letter(2 + j)
        cell = ws_s.cell(row=3, column=2 + j, value=g)
        cell.number_format = PCT_FMT
        cell.font = BOLD

    for i, w in enumerate(wacc_values):
        row = 4 + i
        wcell = ws_s.cell(row=row, column=1, value=w)
        wcell.number_format = PCT_FMT
        wcell.font = BOLD
        for j, g in enumerate(growth_values):
            col_letter = get_column_letter(2 + j)
            g_col_ref = f"{col_letter}$3"
            w_row_ref = f"$A{row}"
            # Formula: recompute TV and PV directly from this sheet's own w/g
            # headers and the FCF + discount-factor rows on 'DCF Model'.
            first_fcf_cell = f"'DCF Model'!$C${row_fcf}"
            formula = (
                f"=IF({w_row_ref}<={g_col_ref},\"n/a\","
                f"(SUMPRODUCT('DCF Model'!{fcf_range}/(1+{w_row_ref})^"
                f"(COLUMN('DCF Model'!{fcf_range})-COLUMN({first_fcf_cell})+1))"
                f"+('DCF Model'!{last_col}{row_fcf}*(1+{g_col_ref})/({w_row_ref}-{g_col_ref}))"
                f"/(1+{w_row_ref})^{refs['proj_years']}"
                f"-{refs['total_debt']}+{refs['cash']}-{refs['minority']})/{refs['shares']})"
            )
            c = ws_s.cell(row=row, column=2 + j, value=formula)
            c.number_format = "$#,##0.00"
            if abs(w - result.wacc) < 1e-9 or i == len(wacc_values) // 2:
                pass

    # Highlight the base-case cell (middle of the grid)
    mid_row = 4 + len(wacc_values) // 2
    mid_col = 2 + len(growth_values) // 2
    ws_s.cell(row=mid_row, column=mid_col).fill = PatternFill("solid", fgColor="FFE699")

    ws_s.cell(row=4 + len(wacc_values) + 2, column=1,
              value="Base case is highlighted. Blank/'n/a' cells occur where WACC ≤ growth rate "
                    "(the Gordon Growth formula is undefined there).").font = Font(italic=True, size=9)

    return wb


def export_dcf_to_excel(result: DCFResult, path: str) -> str:
    wb = build_workbook(result)
    wb.save(path)
    return path
